package aed;

import java.util.ArrayList;
import java.util.Comparator;

public class Heap<T> {
    private ArrayList<Traslado> data;
    private Comparator<Traslado> prioridad;

    public Heap(Traslado[] traslados, Comparator<Traslado> c) {
        data = new ArrayList<Traslado>();
        for (int i = 0; i < traslados.length; i++) {
            data.add(traslados[i]);
        }

        prioridad = c;
    }

    public void registrar(Traslado traslado) {
        int i = data.size();
        
        data.add(traslado);

        while (i > 0 && prioridad.compare(data.get(padre(i)), data.get(i)) < 0) {
            Traslado p = data.set(padre(i), traslado);
            data.set(i, p);
            i = padre(i);
        }
    }

    public int despacharUno() {
        Traslado despachado = data.set(0, data.get(data.size()-1));

        data
    }

    private int padre(int i) {
        return (i-1)/2;
    }
}
