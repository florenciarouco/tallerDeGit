package aed;

public class Ciudad {
    private int ganancia;
    private int perdida;
}
