package aed;

import java.util.ArrayList;

public class Estadisticas {
    private ArrayList<Integer> ciudadesPorMayorGanancia;
    private ArrayList<Integer> ciudadesPorMayorAntiguedad;
    private int ciudadMayorSuperavit;
    private int traslados;
    private int gananciaTotal;
}
